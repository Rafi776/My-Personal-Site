<?php

$email = $_POST['email'];
$message = $_POST['message'];

?>